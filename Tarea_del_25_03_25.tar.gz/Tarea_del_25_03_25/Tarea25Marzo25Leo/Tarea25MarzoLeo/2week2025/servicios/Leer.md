## Generar un formulario en base a las monedas que maneja el servicio, para que el usuario indique de que moneda parte y hacia cual desea realizar la conversión, para luego conseguir la cotización y mostrar la conversión realizada
## Generar una mejora en la misma en donde en el front se pueda ver la cotización de las monedas trabajadas de los ultimos 3 días que presente el servicio.
