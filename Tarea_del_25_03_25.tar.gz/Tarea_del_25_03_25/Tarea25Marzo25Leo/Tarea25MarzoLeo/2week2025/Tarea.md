### En este repositorio encontraran algunos pequeños ejercicios y funciones simples para poder ir ganando confianza en el manejo de un entorno de trabajo sumado a un lenguaje simple pero con grandes prestaciones a futuro


### Listado de tareas a desarrollar

- Pensar en un formulario que sirva para la captura de datos de un evento masivo. (Puede ser cualquier Rubro)
En el formulario se deberań solicitar de minima los siguientes datos (ver el orden en el cual se solicitaran y cuales serán requeridos en forma obligatoria) ** validación**
- Apellidos
- Nombres
- Fecha de la asistencia al evento (el mismo será en 3 días corridos, puede seleccionar 1 como varios)
- Correo electrónico
- Fecha de nacimiento
- Redes sociales
- Perfil del inscripto
- Charla , meet o cursos en los cuales asistira

## Estos datos deberán ser pasados al back, el cual los recibira y realizara algún tipo de validación antes de grabarlos en un archivo plano, manteniendo una estructura. No se podrán tener repetida la casilla de correo, en el caso que suceda se le deberá informar al usuario que ya existe la misma. En el caso de que sea satisfactoria la grabación de los datos, deberá mostrar un mensaje de exito.

## Otro Grupo se deberá encargar de realizar un formulario de consultas brindando al usuario una abanico de posibilidades. Una vez definido el esquema del mismo, deberá coordinar con otro grupo de back para que de acuerdo a su estructura de busqueda el mismo pueda recibir los datos y realizar una búsqueda según el criterio que selecciono el usuario, y mostrar en un formato de tabla la información solicitada en el caso que exista coincidencia o un mensaje en el caso que no lo hubiera.

## Para el desarrollo de esta actividad se pide trabajar de a 2(dos), en donde cada uno asuma un rol diferente. Trabaje dentro de una rama, para luego realizar un merge sobre la rama dev y realizar las pruebas de funcionamiento.