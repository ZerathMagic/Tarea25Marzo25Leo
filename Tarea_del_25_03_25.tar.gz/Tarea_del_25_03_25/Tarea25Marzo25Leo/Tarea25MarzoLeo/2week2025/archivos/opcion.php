<html>
<head>
<title>Encuesta</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#111111">
<p><h1><center><font size="8" face="Arial, Helvetica, sans-serif"><strong><font color="#333333">Que equipo pensas que va a ganar?</center></h1></font></strong></font></p>
<form name="form1" method="post" action="copa.php">
<br><br><p> <font color="#FFFFFFFF" size="5" face="Arial, Helvetica, sans-serif">
<center>  <input type="radio" name="op" value="1" >   </center>
<center><strong><font<  color="#FFFFFFFF" size="5" <strong> Argentina</center></font></strong></font></p>
<center><p> <font color="#FFFFFF" size="5" face="Arial, Helvetica, sans-serif"></center>
<center><input type="radio" name="op" value="2">   </center>
<center><strong><font< color="#FFFFFFFF" size="5" <strong>Brasil</center></font></strong></p>
<center><p> <font color="#FFFFFF"></center>
<center><input type="radio" name="op" value="3">  </center>
<center><font color="#FFFFFF" size="5"><strong>Mexico</center></font></strong></p>
<center><p> <font color="#FFFFFF"></center>
<center><input type="radio" name="op" value="4">  </center>
<center><font color="#FFFFFF" size="5"><strong>Francia</center></strong></font></p>
<center><p> <font color="#FFFFFF"></center>
<center><input type="radio" name="op" value="5">  </center>
<center><font color="#FFFFFF" size="5"><strong>Alemania</center></strong></font></p>
<center><p> <font color="#FFFFFF"></center>
<center><input type="radio" name="op" value="6">  </center>
<center><font color="#FFFFFF" size="5"><strong>España</center></strong></font></p>
<center><p> <font color="#FFFFFF"></center>
<center><input type="submit" name="Submit" value="Enviar"></center>

</font></p>
</form>
<p>&nbsp;</p>
</body>
</html>