## Repositorio con scripts varios en php para empezar a utilizar el lenguaje
## Finalidad utilizar el entorno del Docker 
